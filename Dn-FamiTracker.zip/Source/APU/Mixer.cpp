/*
** Dn-FamiTracker - NES/Famicom sound tracker
** Copyright (C) 2020-2026 D.P.C.M.
** FamiTracker Copyright (C) 2005-2020 Jonathan Liss
** 0CC-FamiTracker Copyright (C) 2014-2018 HertzDevil
**
** This program is free software: you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program. If not, see https://www.gnu.org/licenses/.
*/

/*

 Hardware-based mixing levels are based on NSFPlay's default NSFe
 mixe chunk values: https://github.com/bbbradsmith/nsfplay/blob/master/xgm/player/nsf/nsfplay.cpp#L843

 Exported NSFe files use these constants with delta mix levels
 (CFamiTrackerDoc::m_iDeviceLevelOffset[]) for the "mixe" chunk
 https://www.nesdev.org/wiki/NSFe

 The information below is kept for archival purposes.

*/

/*

 This will mix and synthesize the APU audio using blargg's blip-buffer

 Mixing of internal audio relies on Blargg's findings

 Mixing of external channles are based on my own research:

 VRC6 (Madara):
	Pulse channels has the same amplitude as internal-
	pulse channels on equal volume levels.

 FDS:
	Square wave @ v = $1F: 2.4V
	  			  v = $0F: 1.25V
	(internal square wave: 1.0V)

 MMC5 (just breed):
	2A03 square @ v = $0F: 760mV (the cart attenuates internal channels a little)
	MMC5 square @ v = $0F: 900mV

 VRC7:
	2A03 Square  @ v = $0F: 300mV (the cart attenuates internal channels a lot)
	VRC7 Patch 5 @ v = $0F: 900mV
	Did some more tests and found patch 14 @ v=15 to be 13.77dB stronger than a 50% square @ v=15

 ---

 N163 & 5B are still unknown

*/

#include "../stdafx.h"
#include <memory>
#include <algorithm>
#include <cmath>
#include "Mixer.h"
#include "APU.h"
#include "2A03.h"
#include "MMC5.h"
#include "VRC6.h"
#include "FDS.h"
#include "N163.h"
#include "S5B.h"
#include "utils/variadic_minmax.h"

//#define LINEAR_MIXING

static const float LEVEL_FALL_OFF_RATE = 0.6f;
static const int   LEVEL_FALL_OFF_DELAY = 3;

CMixer::CMixer(CAPU* Parent)
	: m_APU(Parent)
{
	memset(m_iChannels, 0, sizeof(int32_t) * CHANNELS);
	memset(m_fChannelLevels, 0, sizeof(float) * CHANNELS);
	memset(m_iChanLevelFallOff, 0, sizeof(uint32_t) * CHANNELS);

	for (auto i : m_ChipLevels)
		i = 1.0;

	m_iExternalChip = 0;
	m_iSampleRate = 0;

	m_iMeterDecayRate = DECAY_SLOW;		// // // 050B
}

CMixer::~CMixer()
{
}

void CMixer::ExternalSound(int Chip)
{
	m_iExternalChip = Chip;
}

void CMixer::SetChipLevel(chip_level_t Chip, double Level)
{
	m_ChipLevels[Chip] = Level;
}

float CMixer::GetAttenuation(bool UseSurveyMix) const
{
	float ATTENUATION_2A03 = 1.0f;

	if (!UseSurveyMix) {
		constexpr float ATTENUATION_VRC6 = 0.80f;
		constexpr float ATTENUATION_VRC7 = 0.64f;
		constexpr float ATTENUATION_MMC5 = 0.83f;
		constexpr float ATTENUATION_FDS = 0.90f;
		constexpr float ATTENUATION_N163 = 0.70f;
		constexpr float ATTENUATION_S5B = 0.50f;		// // // 050B

		// Increase headroom if some expansion chips are enabled

		if (m_iExternalChip & SNDCHIP_VRC6)
			ATTENUATION_2A03 *= ATTENUATION_VRC6;
		if (m_iExternalChip & SNDCHIP_VRC7)
			ATTENUATION_2A03 *= ATTENUATION_VRC7;
		if (m_iExternalChip & SNDCHIP_FDS)
			ATTENUATION_2A03 *= ATTENUATION_FDS;
		if (m_iExternalChip & SNDCHIP_MMC5)
			ATTENUATION_2A03 *= ATTENUATION_MMC5;
		if (m_iExternalChip & SNDCHIP_N163)
			ATTENUATION_2A03 *= ATTENUATION_N163;
		if (m_iExternalChip & SNDCHIP_S5B)		// // // 050B
			ATTENUATION_2A03 *= ATTENUATION_S5B;
	}
	else {
		// attenuation scaling is exponential based on total chips used
		uint8_t TotalChipsUsed = 1;
		if (m_iExternalChip & SNDCHIP_VRC6) TotalChipsUsed++;
		if (m_iExternalChip & SNDCHIP_VRC7) TotalChipsUsed++;
		if (m_iExternalChip & SNDCHIP_FDS) TotalChipsUsed++;
		if (m_iExternalChip & SNDCHIP_MMC5) TotalChipsUsed++;
		if (m_iExternalChip & SNDCHIP_N163) TotalChipsUsed++;
		if (m_iExternalChip & SNDCHIP_S5B) TotalChipsUsed++;

		ATTENUATION_2A03 *= static_cast<float>(1.0 / (float)TotalChipsUsed);
	}

	return ATTENUATION_2A03;
}

void CMixer::RecomputeEmuMixState()
{
	auto LowCut = m_MixerConfig.LowCut;
	auto HighCut = m_MixerConfig.HighCut;
	auto HighDamp = m_MixerConfig.HighDamp;

	// Blip-buffer filtering
	BlipBuffer.bass_freq(LowCut);

	blip_eq_t eq(-HighDamp, HighCut, m_iSampleRate);

	// See https://docs.google.com/document/d/19vtipTYI-vqL3-BPrE9HPjHmPpkFuIZKvWfevP3Oo_A/edit#heading=h.h70ipevgjbn7
	// for an exploration of how I came to this design.
	for (auto* chip : m_APU->m_SoundChips) {
		chip->UpdateFilter(eq);
	}

	// Volume levels
	auto &chip2A03 = *m_APU->m_p2A03;
	auto &chipMMC5 = *m_APU->m_pMMC5;
	auto &chipVRC6 = *m_APU->m_pVRC6;
	auto &chipVRC7 = *m_APU->m_pVRC7;
	auto &chipFDS = *m_APU->m_pFDS;
	auto &chipN163 = *m_APU->m_pN163;
	auto &chipS5B = *m_APU->m_pS5B;

	bool UseSurveyMixing = m_MixerConfig.UseSurveyMix;

	double Volume = m_MixerConfig.OverallVol * GetAttenuation(UseSurveyMixing);
	
	// Update mixing

	// Maybe the range argument, as well as the constant factor in the volume,
	// should be supplied by the CSoundChip subclass rather than CMixer.
	chip2A03.UpdateMixingAPU1(Volume * m_ChipLevels[CHIP_LEVEL_APU1], UseSurveyMixing);
	chip2A03.UpdateMixingAPU2(Volume * m_ChipLevels[CHIP_LEVEL_APU2], UseSurveyMixing);
	chipMMC5.UpdateMixLevel(Volume * m_ChipLevels[CHIP_LEVEL_MMC5], UseSurveyMixing);
	chipVRC6.UpdateMixLevel(Volume * m_ChipLevels[CHIP_LEVEL_VRC6], UseSurveyMixing);
	chipFDS.UpdateMixLevel(Volume * m_ChipLevels[CHIP_LEVEL_FDS], UseSurveyMixing);
	chipN163.UpdateMixLevel(Volume * m_ChipLevels[CHIP_LEVEL_N163], UseSurveyMixing);
	chipS5B.UpdateMixLevel(Volume * m_ChipLevels[CHIP_LEVEL_S5B], UseSurveyMixing);

	// In legacy mixing, VRC7 level does not decrease as you enable more expansion chips.
	chipVRC7.UpdateMixLevel(
		(UseSurveyMixing ? Volume : m_MixerConfig.OverallVol) * m_ChipLevels[CHIP_LEVEL_VRC7],
		UseSurveyMixing
	);

	// Update per-chip filtering and emulation
	chipN163.UpdateN163Filter(m_MixerConfig.N163Lowpass, m_EmulatorConfig.N163DisableMultiplexing);
	chipFDS.UpdateFDSFilter(m_MixerConfig.FDSLowpass);

	// Update the patch ROM for the VRC7 chip
	ASSERT(!m_EmulatorConfig.UseOPLLPatchBytes.empty());
	ASSERT(m_EmulatorConfig.UseOPLLPatchBytes.size() == 19 * 8);

	chipVRC7.UpdatePatchSet(
		m_EmulatorConfig.UseOPLLPatchSet,
		m_EmulatorConfig.UseOPLLExt,
		&m_EmulatorConfig.UseOPLLPatchBytes[0]);
}

int CMixer::GetMeterDecayRate() const		// // // 050B
{
	return m_iMeterDecayRate;
}

void CMixer::SetMeterDecayRate(int Rate)		// // // 050B
{
	m_iMeterDecayRate = Rate;
}

bool CMixer::AllocateBuffer(unsigned int BufferLength, uint32_t SampleRate, uint8_t NrChannels)
{
	m_iSampleRate = SampleRate;
	BlipBuffer.set_sample_rate(SampleRate, (BufferLength * 1000 * 2) / SampleRate);

	// I don't know if BlipFDS is initialized or not.
	// So I copied the above call to CMixer::UpdateSettings().
	return true;
}

void CMixer::SetClockRate(uint32_t Rate)
{
	// Change the clockrate
	BlipBuffer.clock_rate(Rate);

	// Propagate the change to any sound chips with their own Blip_Buffer.
	// Note that m_APU->m_SoundChips may not have been initialized yet,
	// so CAPU::SetExternalSound() does the same thing.
	for (auto * chip : m_APU->m_SoundChips) {
		chip->SetClockRate(Rate);
	}
}

void CMixer::ClearBuffer()
{
	BlipBuffer.clear();
}

int CMixer::SamplesAvail() const
{
	return (int)BlipBuffer.samples_avail();
}

static int get_channel_level(CSoundChip& chip, int channel) {
	int max = chip.GetChannelLevelRange(channel);
	int level = chip.GetChannelLevel(channel);

	// Clip out-of-bounds levels to the maximum allowed on the meter.
	level = min(level, max);

	int out = level * 16 / (max + 1);
	ASSERT(0 <= out && out <= 15);

	// Ensure that the division process never clips small levels to 0.
	if (level > 0 && out <= 0) {
		out = 1;
	}
	return out;
}

void CMixer::FinishBuffer(int t)
{
	BlipBuffer.end_frame(t);

	for (int i = 0; i < CHANNELS; ++i) {
		// TODO: this is more complicated than 0.5.0 beta's implementation
		if (m_iChanLevelFallOff[i] > 0) {
			if (m_iMeterDecayRate == DECAY_FAST)		// // // 050B
				m_iChanLevelFallOff[i] = 0;
			else
				--m_iChanLevelFallOff[i];
		}
		else if (m_fChannelLevels[i] > 0) {
			if (m_iMeterDecayRate == DECAY_FAST)		// // // 050B
				m_fChannelLevels[i] = 0;
			else {
				m_fChannelLevels[i] -= LEVEL_FALL_OFF_RATE;
				if (m_fChannelLevels[i] < 0)
					m_fChannelLevels[i] = 0;
			}
		}
	}
	
	for (auto* chip : m_APU->m_SoundChips) {
		for (int i = 0; i < chip->GetChannelCount(); i++)
			StoreChannelLevel(chip->GetFirstChannelID() + i, get_channel_level(*chip, i));
	}
}

//
// Mixing
//

void CMixer::AddValue(int ChanID, int Chip, int Value, int AbsValue, int FrameCycles)
{
	// Add sound to mixer
	//

	int Delta = Value - m_iChannels[ChanID];
	StoreChannelLevel(ChanID, AbsValue);
	m_iChannels[ChanID] = Value;
}

int CMixer::ReadBuffer(void *Buffer)
{
	return BlipBuffer.read_samples((blip_amplitude_t*)Buffer, BlipBuffer.samples_avail());
}

int32_t CMixer::GetChanOutput(uint8_t Chan) const
{
	return (int32_t)m_fChannelLevels[Chan];
}

void CMixer::StoreChannelLevel(int Channel, int Value)
{
	int AbsVol = abs(Value);

	if (float(AbsVol) >= m_fChannelLevels[Channel]) {
		m_fChannelLevels[Channel] = float(AbsVol);
		m_iChanLevelFallOff[Channel] = LEVEL_FALL_OFF_DELAY;
	}
}

void CMixer::ClearChannelLevels()
{
	memset(m_fChannelLevels, 0, sizeof(float) * CHANNELS);
	memset(m_iChanLevelFallOff, 0, sizeof(uint32_t) * CHANNELS);
}

uint32_t CMixer::ResampleDuration(uint32_t Time) const
{
	return (uint32_t)BlipBuffer.resampled_duration((blip_nsamp_t)Time);
}
