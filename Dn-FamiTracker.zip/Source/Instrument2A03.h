/*
** Dn-FamiTracker - NES/Famicom sound tracker
** Copyright (C) 2020-2025 D.P.C.M.
** FamiTracker Copyright (C) 2005-2020 Jonathan Liss
** 0CC-FamiTracker Copyright (C) 2014-2018 HertzDevil
**
** This program is free software: you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program. If not, see https://www.gnu.org/licenses/.
*/


#pragma once

#include "FamiTrackerTypes.h"		// // //

class CDSample;

class CInstrument2A03 : public CSeqInstrument, public CInstrument2A03Interface {
public:
	CInstrument2A03();
	CInstrument* Clone() const;
	void	Store(CDocumentFile *pFile);
	bool	Load(CDocumentFile *pDocFile);
	void	SaveFile(CInstrumentFile *pFile);
	bool	LoadFile(CInstrumentFile *pFile, int iVersion);
	// // // for the instrument interface
	int		GetSeqEnable(int Index) const { return CSeqInstrument::GetSeqEnable(Index); }
	int		GetSeqIndex(int Index) const { return CSeqInstrument::GetSeqIndex(Index); }

private:
	char	GetSample(int Octave, int Note) const { return GetSampleIndex(Octave, Note); };		// // //
	int		GetSampleCount() const;		// // // 050B

public:
	// Samples
	char	GetSampleIndex(int Octave, int Note) const;
	char	GetSamplePitch(int Octave, int Note) const;
	bool	GetSampleLoop(int Octave, int Note) const;
	char	GetSampleLoopOffset(int Octave, int Note) const;
	char	GetSampleDeltaValue(int Octave, int Note) const;
	void	SetSampleIndex(int Octave, int Note, char Sample);
	void	SetSamplePitch(int Octave, int Note, char Pitch);
	void	SetSampleLoop(int Octave, int Note, bool Loop);
	void	SetSampleLoopOffset(int Octave, int Note, char Offset);
	void	SetSampleDeltaValue(int Octave, int Note, char Offset);

	bool	AssignedSamples() const;
	const CDSample *GetDSample(int Octave, int Note) const;		// // //

protected:
	virtual void	CloneFrom(const CInstrument *pInst);		// // //

public:
	static LPCTSTR SEQUENCE_NAME[];
	LPCTSTR	GetSequenceName(int Index) const { return SEQUENCE_NAME[Index]; }		// // //

private:
	char	m_cSamples[OCTAVE_RANGE][NOTE_RANGE];				// Samples
	char	m_cSamplePitch[OCTAVE_RANGE][NOTE_RANGE];			// Play pitch/loop
	char	m_cSampleLoopOffset[OCTAVE_RANGE][NOTE_RANGE];		// Loop offset
	char	m_cSampleDelta[OCTAVE_RANGE][NOTE_RANGE];			// Delta setting
};
